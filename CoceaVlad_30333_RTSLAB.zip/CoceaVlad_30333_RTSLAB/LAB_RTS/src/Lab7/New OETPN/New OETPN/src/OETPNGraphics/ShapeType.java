public enum ShapeType {
	Place, Transition, Arc
}
